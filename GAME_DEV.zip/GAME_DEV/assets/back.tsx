<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="back" tilewidth="1920" tileheight="1080" tilecount="1" columns="1">
 <image source="back.png" width="1920" height="1080"/>
</tileset>
