<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="back2" tilewidth="1" tileheight="1" tilecount="20648" columns="178">
 <image source="back2.png" width="178" height="116"/>
</tileset>
