<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="ground" tilewidth="1" tileheight="1" tilecount="73748" columns="358">
 <image source="ground.png" width="358" height="206"/>
</tileset>
