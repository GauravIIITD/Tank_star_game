package com.mygdx.game;

import com.badlogic.gdx.*;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.Screens.Intro;

public class MyGdxGame extends Game {
	public SpriteBatch batch;
//	Texture img;
//	Sprite sprite;
	@Override
	public void create () {
		batch = new SpriteBatch();
		this.setScreen(new Intro(this));
	}

	@Override
	public void render () {
		super.render();

	}
//	public class Menu implements Screen{
//		 public Texture texture;
//		 public Skin skin;
//		 public Stage  stage;
//		 public Menu(){
//			 texture = new Texture(Gdx.files.internal("try2.jpeg"));
//			 skin = new Skin(Gdx.files.internal("skin.json"));
//			 stage = new Stage();
//			 Label mm = new Label("hi", skin, "default");
//			 mm.setSize(100, 100);
//			 mm.setPosition(0,0);
//
//		 }
//
//		@Override
//		public void show() {
//
//		}
//
//		@Override
//		public void render(float delta) {
//
//		}
//
//		@Override
//		public void resize(int width, int height) {
//
//		}
//
//		@Override
//		public void pause() {
//
//		}
//
//		@Override
//		public void resume() {
//
//		}
//
//		@Override
//		public void hide() {
//
//		}
//
//		@Override
//		public void dispose() {
//
//		}
//	}

//	@Override
//	public void dispose () {
//		batch.dispose();
//		img.dispose();
//	}
	//if enter key is pressed open another image


//	@Override
//	public void OrthographicCamera() {
//		// TODO Auto-generated method stub
//		OrthographicCamera resize = new OrthographicCamera(Gdx.graphics.getWidth()/2, Gdx.graphics.getHeight()/2);
//		resize.translate(Gdx.graphics.getWidth()/2/2, Gdx.graphics.getHeight()/2/2);
//
//	}
}
