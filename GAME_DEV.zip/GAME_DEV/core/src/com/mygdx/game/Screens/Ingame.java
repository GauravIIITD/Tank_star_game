package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthoCachedTiledMapRenderer;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MyGdxGame;

public class Ingame implements Screen {
    MyGdxGame game;
    private OrthographicCamera camera;
    private Viewport port;
    private TmxMapLoader tmxMapLoader;
    private TiledMap map;
    private OrthoCachedTiledMapRenderer orthoCachedTiledMapRenderer;
    private Stage stage4, stage5;
    private Texture textureBackground1, pausePrompt;
    private boolean flag;
    private Skin skin;
    private TextButton textButton1;
    private TextButton textButton2;
    private TextButton textButton3;
    private ImageButton button, returnBack;
    Ingame(MyGdxGame game) {
        flag = false;
        stage4 = new Stage();
        stage5 = new Stage();
        this.game = game;

        textureBackground1 = new Texture(Gdx.files.internal("ingp (1).png"));
        button = new ImageButton(new TextureRegionDrawable(new Texture(Gdx.files.internal("pause.png"))));
        button.setSize(150, 100);
        button.setPosition(0,950);
//        returnBack = new ImageButton(new TextureRegionDrawable(new Texture(Gdx.files.internal("ign menu.png"))));
//        returnBack.setPosition(700, 400);
        pausePrompt = new Texture(Gdx.files.internal("ign menu.png")) ;
//        button.setPosition(400, 200);
//        button.setSize(200,75);
        //try = pause button menu
        stage4.addActor(button);
//        stage5.addActor(returnBack);
        Gdx.input.setInputProcessor(stage4);

//        camera = new OrthographicCamera();
//        port = new FitViewport(1920, 1080);
//        tmxMapLoader = new TmxMapLoader();
//        map = tmxMapLoader.load("Untitled1.tmx");
//        orthoCachedTiledMapRenderer = new OrthoCachedTiledMapRenderer(map);
//        camera.position.set(1920/2, 1080/2, 0);

    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        if(flag){
            Gdx.input.setInputProcessor(stage5);
        }
        ScreenUtils.clear(0, 0, 0, 0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(textureBackground1, 0, 0);
        game.batch.end();
        stage4.draw();
        if(flag){
            game.batch.begin();
            game.batch.draw(pausePrompt, 700, 285);
            game.batch.end();
            stage5.act(Gdx.graphics.getDeltaTime());
            stage5.draw();
        }
        button.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                flag = true;
                Gdx.input.setInputProcessor(stage5);
            }
        });
        if (Gdx.input.getX() > 705 && Gdx.input.getX() < 1237 && Gdx.input.getY() > 395 && Gdx.input.getY() < 601) {
            if (Gdx.input.justTouched()) {
                dispose();
                game.setScreen(new Ingame(game));
            }
        }
            if (Gdx.input.getX() > 705 && Gdx.input.getX() < 1237 && Gdx.input.getY() > 656 && Gdx.input.getY() < 735) {
                if (Gdx.input.justTouched()) {
                    dispose();
                    game.setScreen(new MainMenu(game));
                }
            }
        ;
//        returnBack.addListener(new ClickListener(){
//            @Override
//            public void clicked(InputEvent event, float x, float y) {
////                System.out.println("yes");
////                stage5.dispose();
//                flag = false;
//                Gdx.input.setInputProcessor(stage4);
//            }
//        });

//        Gdx.gl.glClearColor(0, 0, 0, 1);
//        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
//        camera.update();
//        orthoCachedTiledMapRenderer.setView(camera);
//        orthoCachedTiledMapRenderer.render();
//        game.batch.setProjectionMatrix(camera.combined);
//        game.batch.begin();
//        game.batch.draw(textureBackground1, 0, 0);
//        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage4.dispose();
        stage5.dispose();
    }
}
